@echo off
title Informacion del Equipo
color 0A

echo ==========================================
echo         INFORMACION DEL SISTEMA
echo ==========================================
echo.
echo Nombre del equipo: %COMPUTERNAME%
echo.
echo Direcciones IP locales:
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    echo   -%%a
)
echo.
echo ==========================================
pause
